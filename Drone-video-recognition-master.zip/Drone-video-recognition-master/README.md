# 识别无人机 DroneVideoRecognition

## 依赖包安装

    pip install opencv-contrib-python
    pip install PyQt5
    pip install imutils

## 运行

    ./main.py

## 其他说明

csdn的地址，详细的写了整个实现的过程：
https://blog.csdn.net/bi_diu1368/article/details/82586675

有问题联系邮箱：
weim2018@163.com
