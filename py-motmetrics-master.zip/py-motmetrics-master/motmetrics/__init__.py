
from .mot import MOTAccumulator
import motmetrics.lap
import motmetrics.metrics
import motmetrics.distances
import motmetrics.io
import motmetrics.utils


# Needs to be last line
__version__ = '1.1.3'