# Mobilenet V2
This folder contains building code for Mobilenet V2, based on
[Inverted Residuals and Linear Bottlenecks: Mobile Networks for Classification, Detection and Segmentation]
(https://arxiv.org/abs/1801.04381)

# Pretrained model
TODO

# Example
TODO


