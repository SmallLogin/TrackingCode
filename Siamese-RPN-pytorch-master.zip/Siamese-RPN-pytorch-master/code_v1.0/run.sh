python train_siamrpn.py --train_path=/home/song/srpn/dataset/vid/ILSVRC2015_VID_train_0000
#python train_siamrpn.py --train_path=/home/song/srpn/dataset/simple_vot13 --debug=True
#python train_siamrpn.py --train_path=/home/song/srpn/dataset/vid/ILSVRC2015_VID_train_0000
#CUDA_VISIBLE_DEVICES=0,1 python otb_SiamRPN.py