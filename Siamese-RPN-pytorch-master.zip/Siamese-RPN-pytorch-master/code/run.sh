
python train_siamrpn.py --train_path=/home/song/srpn/dataset/vot2013
#python train_siamrpn.py --train_path=/home/song/srpn/dataset/simple_vot13
#CUDA_VISIBLE_DEVICES=0,1 python otb_SiamRPN.py