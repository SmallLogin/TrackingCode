# Quadrotor-UAV-target-tracking
a simple demo for Quadrotor UAV target tracking

Results
==


![Image text](https://github.com/marsmarcin/Quadrotor-UAV-target-tracking/blob/master/result/test07-2min.gif)
